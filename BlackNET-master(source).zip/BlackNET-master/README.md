<p align="center">
 <img src="https://a.top4top.net/p_1104t3ole1.png" alt="" />
</p>

<p align="center">
 <a href="#"><img align="center" src="https://img.shields.io/maintenance/yes/2020" /></a> 
 <a href="#"><img align="center" src="https://img.shields.io/github/license/BlackHacker511/BlackNET" /></a>
 <a href="#"><img align="center" src="https://img.shields.io/github/v/release/BlackHacker511/BlackNET" /></a>
 <a href="#"><img align="center" src="https://app.fossa.com/api/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET.svg?type=shield"/></a>
 <a href="#"><img align="center" src="http://isitmaintained.com/badge/resolution/BlackHacker511/BlackNET.svg" /></a>
</p>

# BlackNET
Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.

## About BlackNET
Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.

this botnet controller comes with a lot of features and the most secure panel for free

Developed By: Black.Hacker

## What You Can Do
 1. Upload File
 2. DDOS Attack [ TCP,UDP,ARME,Slowloris, HTTPGet, POSTHttp, Bandwidth Flood ]
    + Start DDOS
    + Stop DDOS
 3. Open Webpage
     + Visible
     + Hidden
 4. Show MessageBox
 5. Take Screenshot
 6. Steal Firefox Cookies
 7. Steal Saved Passwords
 8. Keylogger
 9. Execute Scripts
10. Computer Operations
    + Restart
    + Shutdown
    + Logout
11. Bitcoint Wallet Stealer
12. Uninstall Client
13. Move Client
14. Blacklist Client
15. Update Client
16. Close Client
 
## Requirements
1. PHP >=  7.0
2. NET Framework
    + Stub >= 2.0
    + Builder >= 4.0

## How to Install PHP Panel
1. Clone this Repo
2. Compress BlackNET panel folder and upload it to your hosting
3. Create a database with any name you want
4. Change the data in classes/Database.php
5. Change files and folders permission to 777 [ Uploads Folder, Scripts Folder ]
6. Go to install.php to create the botnet tables automatically

## Screenshots
![Installtion Page](https://i.imgur.com/RwNTwgs.png)

![Image of Login Page](https://b.top4top.io/p_1482shh7l1.png)

![Image of the interface](https://j.top4top.io/p_1482stt3l1.png)

![Image of the Builder](https://i.gyazo.com/3009893d1d8df53ca783d52406199448.png)

## Stub Scan Result

<img src="https://4.top4top.net/p_1456uda0g1.png" alt="How to encrypt BlackNET" width="340" hieght="775" />

## YouTube Tutorials
[How to install BlackNET v2.0](https://www.youtube.com/watch?v=ReKOuh6fFcQ)

[How to update BlackNET to v2.5](https://youtu.be/07XioeJvPZk)

[How to obfuscate BlackNET](https://www.youtube.com/watch?v=hzC8_UYGor0)

[How to Setup BlackNET Cron Job System](https://www.youtube.com/watch?v=rHCYGRA1h54)

## What's New

````
v3.0.0.1
  Vuln: Auth.php bypass (fixed)
  Bug: Typo => #54 ( fixed )
  Edit: Removed Connection Password
  Bug Fixes
````

## Coming Soon
````
v3.5
````

## Pull Request
1. Fork the repo
2. Add your feature
3. Create a pull request

i will review it in 1 - 5 days then i will merge it with the master branch

## Thanks to
- Underc0de
- KFC
- Yck1509
- NYAN CAT

## Python Edition
[BlackHacker511/BlackNET-Python](http://github.com/BlackHacker511/BlackNET-Python)

## Donate
<a target="_blank" href="http://paypal.me/BlackHacker1"><img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" /></a>

BTC: 1DXMk3Dm2GXUsLe9ZFmNNs9jxa2qNX9GfW

<a href="https://ko-fi.com/blackhacker"><img src="https://3.top4top.net/p_1460d94yj1.png" width="217" hieght="51" /><a>
<a href="http://www.patreon.com/blackhacker511"><img src="https://c5.patreon.com/external/logo/become_a_patron_button.png" width="217" hieght="51" /><a>
<a href="https://www.buymeacoffee.com/blackhacker511" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/guidelines/download-assets-sm-2.svg" alt="Buy Me A Coffee" ></a>
 
 <a href="https://opencollective.com/blacknet#support"><img src="https://opencollective.com/blacknet/sponsors.svg" /></a>

## LEGAL DISCLAIMER PLEASE READ!
##### I, the creator and all those associated with the development and production of this program are not responsible for any actions and or damages caused by this software. You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only. This software's intended purpose is NOT to be used maliciously, or on any system that you do not have own or have explicit permission to operate and use this program on. By using this software, you automatically agree to the above.

## License
This project is licensed under the MIT License

[![FOSSA Status](https://app.fossa.io/api/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET.svg?type=large)](https://app.fossa.io/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET?ref=badge_large)

## Copyright
[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/) 

Copyright © Black.Hacker - 2020
